import * as THREE from 'three';

export function createZone(scene) {
  const group = new THREE.Group();
  group.name = 'The approaching mist';
  scene.add(group);
  const sceneryScale = scene.scale.x || 1;
  const uniforms = { uTime: { value: 0 }, uDanger: { value: 0 } };
  const wallMaterial = new THREE.ShaderMaterial({
    uniforms, transparent: true, depthWrite: false, side: THREE.DoubleSide,
    vertexShader: `varying vec2 vUv; void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}`,
    fragmentShader: `
      varying vec2 vUv; uniform float uTime; uniform float uDanger;
      void main(){
        float edge=pow(1.0-vUv.y,2.3);
        float wave=sin(vUv.x*143.0+sin(vUv.y*10.0-uTime*.8)*2.0+uTime*.35)*.5+.5;
        float mist=sin(vUv.x*77.0-vUv.y*8.0+uTime*.45)*sin(vUv.x*31.0+vUv.y*12.0-uTime*.25)*.5+.5;
        float filaments=pow(wave,12.0)*pow(1.0-vUv.y,1.4);
        vec3 low=mix(vec3(.60,.28,.70),vec3(.95,.23,.38),uDanger*.65);
        vec3 color=mix(low,vec3(.28,.35,.65),vUv.y)+vec3(.52,.28,.42)*filaments;
        float alpha=(edge*.28+mist*edge*.24+filaments*.23)*(.86+.14*sin(uTime*1.8));
        alpha *= 1.0-smoothstep(.55,1.0,vUv.y);
        gl_FragColor=vec4(color,alpha);
      }
    `,
  });
  const wall=new THREE.Mesh(new THREE.CylinderGeometry(1,1,7.2,160,8,true),wallMaterial);
  wall.position.y=3.6; wall.renderOrder=4; group.add(wall);
  const borderMaterial=new THREE.ShaderMaterial({
    uniforms, transparent:true,depthWrite:false,side:THREE.DoubleSide,blending:THREE.AdditiveBlending,
    vertexShader:`varying vec2 vUv;void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}`,
    fragmentShader:`
      varying vec2 vUv;uniform float uTime;uniform float uDanger;
      void main(){
        float r=length(vUv-.5)*2.0;
        float glow=exp(-abs(r-.975)*150.0);
        float ripple=.7+.3*sin(atan(vUv.y-.5,vUv.x-.5)*42.0-uTime*2.0);
        vec3 color=mix(vec3(.8,.35,.92),vec3(1.,.22,.36),uDanger);
        gl_FragColor=vec4(color,glow*ripple*.95);
      }
    `,
  });
  const border=new THREE.Mesh(new THREE.PlaneGeometry(2.06,2.06),borderMaterial);
  border.rotation.x=-Math.PI/2;border.position.y=.055;border.renderOrder=5;group.add(border);
  const hazeMaterial=new THREE.ShaderMaterial({
    uniforms:{...uniforms,uRadius:{value:32}},transparent:true,depthWrite:false,side:THREE.DoubleSide,
    vertexShader:`varying vec3 vWorld;void main(){vWorld=(modelMatrix*vec4(position,1.)).xyz;gl_Position=projectionMatrix*viewMatrix*vec4(vWorld,1.);}`,
    fragmentShader:`
      varying vec3 vWorld;uniform float uRadius;uniform float uTime;uniform float uDanger;
      void main(){
        float distanceFromCenter=length(vWorld.xz);
        if(distanceFromCenter < uRadius-.16) discard;
        float outside=smoothstep(uRadius-.16,uRadius+2.8,distanceFromCenter);
        float slow=sin(vWorld.x*.20+uTime*.16)*sin(vWorld.z*.18-uTime*.12);
        float curls=sin(vWorld.x*.52-vWorld.z*.30+uTime*.35)*sin(vWorld.z*.39+uTime*.18);
        float cloud=clamp(.54+slow*.27+curls*.18,0.,1.);
        float veins=pow(.5+.5*sin(vWorld.x*.72+vWorld.z*.41-uTime*.7+curls),5.);
        vec3 violet=mix(vec3(.32,.17,.48),vec3(.66,.35,.77),cloud);
        violet=mix(violet,vec3(.77,.27,.54),uDanger*.18+veins*.12);
        float heightAlpha=vWorld.y > 1.0 ? .59 : 1.0;
        gl_FragColor=vec4(violet,outside*(.46+cloud*.23+veins*.06)*heightAlpha);
      }
    `,
  });
  const haze=new THREE.Mesh(new THREE.PlaneGeometry(400,400),hazeMaterial);
  haze.rotation.x=-Math.PI/2;haze.position.y=.11;haze.renderOrder=3;group.add(haze);
  const upperHaze=new THREE.Mesh(haze.geometry,hazeMaterial);
  upperHaze.rotation.x=-Math.PI/2;upperHaze.position.y=2.4;upperHaze.renderOrder=3;group.add(upperHaze);
  const puffCount=104;
  const puffMaterial=new THREE.MeshBasicMaterial({color:'#bd7ce0',transparent:true,opacity:.34,
    depthWrite:false,side:THREE.DoubleSide,toneMapped:false});
  const puffs=new THREE.InstancedMesh(new THREE.SphereGeometry(.85,7,5),puffMaterial,puffCount);
  puffs.name='Billowing violet poison mist';
  puffs.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
  const puffSeeds=[];
  const puffTransform=new THREE.Object3D();
  const puffColor=new THREE.Color();
  for(let i=0;i<puffCount;i++){
    const phase=i*12.9898%6.28;
    puffSeeds.push({angle:i*2.399963229728653,phase,offset:2.0+Math.sqrt((i+.5)/puffCount)*22,
      height:1.1+(i%6)*.65,width:1.7+(i*17%12)/10,tall:1.0+(i*13%15)/10,speed:.18+(i*19%17)/55});
    puffColor.set(i%3?'#bc75dc':'#a75ed0');puffs.setColorAt(i,puffColor);
  }
  group.add(puffs);
  return {update(time,radius,inDanger){
    uniforms.uTime.value=time;
    uniforms.uDanger.value=THREE.MathUtils.lerp(uniforms.uDanger.value,inDanger?1:0,.06);
    wall.scale.set(radius,1,radius);border.scale.set(radius,radius,1);
    hazeMaterial.uniforms.uRadius.value=radius*sceneryScale;
    puffMaterial.opacity=.31+.05*(.5+.5*Math.sin(time*1.7));
    puffSeeds.forEach((puff,index)=>{
      const angle=puff.angle+Math.sin(time*puff.speed+puff.phase)*.035;
      const cloudRadius=radius+puff.offset+Math.sin(time*.58+puff.phase)*.55;
      puffTransform.position.set(Math.cos(angle)*cloudRadius,puff.height+Math.sin(time*.8+puff.phase)*.48,Math.sin(angle)*cloudRadius);
      puffTransform.rotation.set(Math.sin(time*.6+puff.phase)*.16,time*.06+puff.phase,Math.cos(time*.5+puff.phase)*.13);
      const scale=1+Math.sin(time*1.25+puff.phase)*.14;
      puffTransform.scale.set(puff.width*scale,puff.tall*scale,1.1*scale);
      puffTransform.updateMatrix();puffs.setMatrixAt(index,puffTransform.matrix);
    });
    puffs.instanceMatrix.needsUpdate=true;
  }};
}
