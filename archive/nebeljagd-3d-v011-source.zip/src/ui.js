const icon = (name, className = '') => {
  const shapes = {
    leaf: '<path d="M19 3C9 2 3 7 4 13c.6 4 4 6 7 5 6-2 8-9 8-15Z"/><path d="M4 21 15 9M8 16l-1-5m5 1 4 1"/>',
    diamond: '<path d="m12 2 7 10-7 10-7-10Z"/><path d="m5 12 7-3 7 3m-7-3v13"/>',
    heart: '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z"/>',
    fog: '<path d="M4 7h9m3 0h4M2 12h20M5 17h6m3 0h5"/><path d="m10 3 2-2 2 2"/>',
    arrow: '<path d="M4 12h15m-6-6 6 6-6 6"/>',
    pause: '<path d="M8 5v14M16 5v14"/>',
    dash: '<path d="m13 2-8 12h6l-1 8 9-13h-7l1-7Z"/>',
    roll: '<path d="M4 11a8 8 0 1 1 2.2 7M4 11V5m0 6h6"/><circle cx="12" cy="13" r="2"/>',
    bow: '<path d="M7 3c8 2 13 10 10 18M7 3c-8 3-8 15 10 18M7 3l10 18M3 13l17-4m-4-3 4 3-2 4"/>',
    sword: '<path d="m19 3 2 2-9 10-3-3 10-9ZM8 12l4 4m-8-1 5 5m-3-7 5 5m-5 3 3-3"/>',
    hand: '<path d="M8 13V7a1.5 1.5 0 0 1 3 0v4-6a1.5 1.5 0 0 1 3 0v6-4a1.5 1.5 0 0 1 3 0v5-2a1.5 1.5 0 0 1 3 0v4c0 4-2 7-7 7h-2c-3 0-4-2-7-6a1.5 1.5 0 0 1 2-2l2 2Z"/>',
    compass: '<circle cx="12" cy="12" r="9"/><path d="m16 8-3 5-5 3 3-5 5-3Z"/>',
    shield: '<path d="m12 2 8 3v6c0 5-8 11-8 11S4 16 4 11V5l8-3Z"/><path d="m8 12 3 3 5-6"/>',
    return: '<path d="m8 4-5 5 5 5M3 9h11a6 6 0 0 1 0 12h-3"/>',
  };
  return `<svg class="icon ${className}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${shapes[name] || shapes.leaf}</svg>`;
};

const portrait = `<svg viewBox="0 0 64 64" aria-hidden="true"><defs><linearGradient id="hoodGradient" x2="0" y2="1"><stop stop-color="#5d9980"/><stop offset="1" stop-color="#183f36"/></linearGradient></defs><path fill="#172d28" d="M0 0h64v64H0z"/><circle cx="32" cy="30" r="24" fill="#355d4c"/><path fill="url(#hoodGradient)" d="M10 57c1-10 4-12 9-16-7-13-3-29 13-34 17 5 21 21 13 34 5 4 8 8 9 16Z"/><path fill="#192f2b" d="M20 28c2-11 8-15 12-17 7 5 11 11 12 18l-4 16H24Z"/><path fill="#e8b78b" d="m22 28 3 17 7 5 7-5 3-17-10-5Z"/><path fill="#d4a15e" d="m21 28 4-9 8-4 9 12-8-5-4 7-2-4Z"/><path stroke="#443a2b" stroke-width="2" d="M26 33h3m6 0h3"/><path fill="#58836c" d="m19 42 13 10 13-10 9 18H10Z"/><path fill="#be9b57" d="m28 51 4-2 4 2-4 7Z"/></svg>`;

const pad = n => String(Math.max(0, Math.floor(n))).padStart(2, '0');
const timeLabel = seconds => `${pad(seconds / 60)}:${pad(seconds % 60)}`;

export function createUI({ onStart, onPause, onResume, onRestart, onDash, onAttack, onInteract, onQualityChange } = {}) {
  const root = document.getElementById('ui');
  root.dataset.phase = 'ready';
  root.innerHTML = `
    <div class="world-vignette" aria-hidden="true"></div>
    <header class="brand-lockup">
      <div class="brand-mark">${icon('leaf')}</div>
      <div><div class="brand-title">NEBELJAGD</div><div class="brand-subtitle">DIE NEBELINSEL</div></div>
    </header>

    <div class="zone-panel playing-only" id="zonePanel">
      <span class="zone-icon">${icon('fog')}</span>
      <div class="zone-copy"><span class="eyebrow" id="zoneLabel">DER NEBEL ZIEHT AUF</span><div><strong id="zoneTime">01:30</strong><span class="zone-separator">/</span><span id="zoneRadius">44 m</span></div></div>
      <div class="zone-track"><div id="zoneProgress"></div></div>
    </div>

    <div class="top-tools playing-only">
      <button id="pauseBtn" class="icon-button" aria-label="Spiel pausieren" title="Pause · Esc">${icon('pause')}</button>
    </div>
    <aside class="map-panel playing-only" aria-label="Minikarte der Insel">
      <span class="map-north">N</span><canvas id="minimap" width="256" height="256" aria-label="Deine Position und die sichere Zone"></canvas>
      <span class="map-caption">NEBELINSEL</span>
    </aside>

    <section class="player-panel playing-only" aria-label="Spielfigur und Gesundheit">
      <div class="portrait">${portrait}<span class="portrait-level">I</span></div>
      <div class="player-info"><div class="player-name-row"><strong>Waldläufer</strong><span id="healthValue">75 <small>/ 100</small></span></div>
        <div id="healthBar" class="health-track" role="progressbar" aria-label="Lebenspunkte" aria-valuemin="0" aria-valuemax="100" aria-valuenow="75"><div id="healthFill"></div><span class="health-segments"></span></div>
        <div class="player-status" id="playerStatusWrap"><span class="status-dot"></span><span id="playerStatus">Bereit für das Unbekannte</span></div>
      </div>
    </section>

    <div class="inventory playing-only"><span class="inventory-icon">${icon('diamond')}</span><strong id="crystalCount">0</strong><span>Kristalle</span></div>
    <div class="weapon-status playing-only" id="weaponStatus" aria-label="Ausgerüstete Waffe: Leer" aria-live="polite"><span class="weapon-status-icon" id="weaponIcon">${icon('shield')}</span><span class="weapon-status-copy"><small>WAFFE</small><strong id="weaponName">Leer</strong></span></div>
    <button id="pickupPrompt" class="pickup-prompt playing-only" aria-label="Waffe mit E aufnehmen" hidden>${icon('hand')}<span class="pickup-key"><kbd>E</kbd> aufnehmen</span><strong id="pickupItem">Bogen</strong></button>
    <div class="desktop-controls playing-only"><span class="key-cluster"><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd></span><span>Bewegen</span><i></i><kbd class="space-key">LEERTASTE</kbd><span>Rolle</span><i></i><kbd>F</kbd><span>Angriff</span><i></i><kbd>E</kbd><span>Aufheben</span></div>
    <div class="touch-controls playing-only">
      <div id="joystick" class="joystick" role="group" aria-label="Virtueller Bewegungsjoystick"><span class="joystick-cross"></span><div id="joystickKnob" class="joystick-knob">${icon('compass')}</div></div>
      <div class="touch-actions">
        <button id="pickupBtn" class="pickup-button" aria-label="Waffe aufheben" hidden>${icon('hand')}<span>AUFHEBEN</span></button>
        <button id="dashBtn" class="dash-button" aria-label="Rolle ausführen">${icon('roll')}<span>ROLLE</span></button>
        <button id="attackBtn" class="attack-button" aria-label="Angriff" disabled>${icon('sword')}<span>ANGRIFF</span></button>
      </div>
    </div>

    <div class="danger-warning playing-only" id="dangerWarning" role="status">${icon('fog')}<span>Du bist im Nebel. Zurück in die sichere Zone!</span></div>
    <div id="toast" class="toast" role="status" aria-live="polite"></div>

    <section class="intro-screen" id="startScreen" aria-labelledby="introTitle">
      <div class="intro-atmosphere" aria-hidden="true"></div>
      <div class="intro-card">
        <div class="intro-eyebrow"><span></span>EIN NEUES KAPITEL</div>
        <h1 id="introTitle">Der Wald<br><em>erwacht.</em></h1>
        <p class="intro-description">Erkunde verborgene Häuser, werde im hohen Gras unsichtbar und finde deinen Weg durch den lila Nebel.</p>
        <div class="intro-features"><span>${icon('leaf')}Erkunden</span><span>${icon('heart')}Sammeln</span><span>${icon('shield')}Überleben</span></div>
        <button id="startBtn" class="primary-button"><span>Insel betreten</span>${icon('arrow')}</button>
        <div class="intro-controls"><span class="desktop-hint">WASD / PFEILE <b>BEWEGEN</b><span>·</span> LEERTASTE <b>ROLLE</b><span>·</span> F <b>ANGRIFF</b><span>·</span> E <b>AUFHEBEN</b></span><span class="touch-hint">JOYSTICK ZUM BEWEGEN · TASTEN FÜR ROLLE UND ANGRIFF</span></div>
      </div>
      <div class="intro-location"><span>01</span><div>Die Nebelinsel<small>Ein Ort voller Geheimnisse</small></div></div>
    </section>

    <section class="modal-screen" id="pauseScreen" aria-labelledby="pauseTitle" hidden>
      <div class="modal-card"><span class="modal-emblem">${icon('leaf')}</span><div class="eyebrow">EIN MOMENT DER RUHE</div><h2 id="pauseTitle">Durchatmen.</h2><p>Die Insel wartet auf dich.</p>
        <button id="resumeBtn" class="primary-button"><span>Weiter erkunden</span>${icon('arrow')}</button>
        <button id="restartBtn" class="secondary-button">Neu beginnen</button>
        ${onQualityChange ? '<label class="quality-option" for="qualityMode">Darstellung<select id="qualityMode"><option value="high">Detailreich</option><option value="low">Leistung</option></select></label>' : ''}
        <p class="pause-help desktop-hint">WASD / Pfeile · Bewegen<br>Leertaste · Rolle &nbsp; F · Angriff &nbsp; E · Aufheben<br>Esc · Pause</p>
      </div>
    </section>
    <section class="modal-screen" id="deathScreen" aria-labelledby="deathTitle" hidden>
      <div class="modal-card"><span class="modal-emblem">${icon('fog')}</span><div class="eyebrow">DER NEBEL HAT DICH GEFUNDEN</div><h2 id="deathTitle">Ein neuer Anfang.</h2><p>Jeder Weg durch den Wald lehrt dich etwas.</p><div class="round-result"><span>Erkundet<strong id="finalTime">00:00</strong></span><span>Kristalle<strong id="finalCrystals">0</strong></span></div><button id="retryBtn" class="primary-button"><span>Zurück auf die Insel</span>${icon('return')}</button></div>
    </section>
    <section class="modal-screen error-screen" id="errorScreen" hidden><div class="modal-card"><span class="modal-emblem">${icon('fog')}</span><h2>Die Insel ist noch im Nebel.</h2><p id="errorMessage"></p></div></section>
  `;

  const $ = id => document.getElementById(id);
  const healthFill = $('healthFill');
  const healthValue = $('healthValue');
  const healthBar = $('healthBar');
  const zoneTime = $('zoneTime');
  const zoneRadius = $('zoneRadius');
  const zonePanel = $('zonePanel');
  const zoneLabel = $('zoneLabel');
  const zoneProgress = $('zoneProgress');
  const crystalCount = $('crystalCount');
  const playerStatus = $('playerStatus');
  const dangerWarning = $('dangerWarning');
  const map = $('minimap');
  const mapContext = map.getContext('2d');
  const toastElement = $('toast');
  const dashButton = $('dashBtn');
  const attackButton = $('attackBtn');
  const interactButton = $('pickupBtn');
  const pickupPrompt = $('pickupPrompt');
  const weaponStatus = $('weaponStatus');
  const weaponIcon = $('weaponIcon');
  const weaponName = $('weaponName');
  const pickupItem = $('pickupItem');
  let currentPhase = 'ready';
  let latestState = {};
  let toastTimeout;
  let lastMapTime = -Infinity;
  let lastHealth = -1;
  let lastDanger = false;
  let lastWeaponType;
  let lastNearWeaponType;

  $('startBtn').addEventListener('click', () => onStart?.());
  $('pauseBtn').addEventListener('click', () => onPause?.());
  $('resumeBtn').addEventListener('click', () => onResume?.());
  $('restartBtn').addEventListener('click', () => onRestart?.());
  $('retryBtn').addEventListener('click', () => onRestart?.());
  dashButton.addEventListener('pointerdown', event => { event.preventDefault(); onDash?.(); });
  attackButton.addEventListener('pointerdown', event => { event.preventDefault(); if (!attackButton.disabled) onAttack?.(); });
  interactButton.addEventListener('pointerdown', event => { event.preventDefault(); if (!interactButton.disabled) onInteract?.(); });
  pickupPrompt.addEventListener('pointerdown', event => { event.preventDefault(); if (!pickupPrompt.disabled) onInteract?.(); });
  attackButton.addEventListener('click', event => { if (event.detail === 0 && !attackButton.disabled) onAttack?.(); });
  interactButton.addEventListener('click', event => { if (event.detail === 0 && !interactButton.disabled) onInteract?.(); });
  pickupPrompt.addEventListener('click', event => { if (event.detail === 0 && !pickupPrompt.disabled) onInteract?.(); });
  $('qualityMode')?.addEventListener('change', event => onQualityChange?.(event.target.value));

  function setPhase(phase) {
    if (!['ready', 'playing', 'paused', 'dead'].includes(phase)) return;
    currentPhase = phase;
    root.dataset.phase = phase;
    $('startScreen').hidden = phase !== 'ready';
    $('pauseScreen').hidden = phase !== 'paused';
    $('deathScreen').hidden = phase !== 'dead';
    $('pauseBtn').disabled = phase !== 'playing';
    if (phase === 'dead') {
      $('finalTime').textContent = timeLabel(latestState.elapsed || 0);
      $('finalCrystals').textContent = String(latestState.crystals || 0);
    }
  }

  function drawMap(state) {
    if (!mapContext) return;
    const ctx = mapContext;
    const size = map.width;
    const center = size / 2;
    const scale = size / 101;
    const point = (x, z) => [center + x * scale, center + z * scale];
    ctx.clearRect(0, 0, size, size);
    ctx.save();
    ctx.beginPath(); ctx.arc(center, center, center - 3, 0, Math.PI * 2); ctx.clip();
    ctx.fillStyle = '#132d2c'; ctx.fillRect(0, 0, size, size);
    ctx.strokeStyle = '#d3b9790b'; ctx.lineWidth = 1;
    for (let i = 16; i < size; i += 28) { ctx.beginPath(); ctx.moveTo(i, 0); ctx.lineTo(i, size); ctx.moveTo(0, i); ctx.lineTo(size, i); ctx.stroke(); }
    ctx.fillStyle = '#52664b'; ctx.beginPath(); ctx.arc(center, center, 44 * scale, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#a1ac7838'; ctx.lineWidth = 3; ctx.stroke();
    ctx.strokeStyle = '#67a09b'; ctx.lineWidth = 4.6 * scale; ctx.lineCap = 'round'; ctx.beginPath();
    for (let z = -44; z <= 44; z += 1) { const [x, y] = point(9 + Math.sin(z * .085) * 4, z); z === -44 ? ctx.moveTo(x, y) : ctx.lineTo(x, y); }
    ctx.stroke();
    ctx.strokeStyle = '#d8cba45e'; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(...point(-33, 6)); ctx.quadraticCurveTo(...point(-6, 4), ...point(26, 6)); ctx.stroke();
    ctx.strokeStyle = '#f0d4a6'; ctx.lineWidth = 4; ctx.beginPath(); ctx.moveTo(...point(6, 5.5)); ctx.lineTo(...point(14, 5.5)); ctx.stroke();
    for (const house of state.houses || []) {
      const [hx, hy] = point(house.x, house.z);
      const width = (house.halfWidth || 8) * scale;
      const depth = (house.halfDepth || 7) * scale;
      ctx.save(); ctx.translate(hx, hy);
      ctx.fillStyle = house.active ? '#b8986d' : '#766049';
      ctx.fillRect(-width, -depth, width * 2, depth * 2);
      ctx.strokeStyle = '#f1e5c0c0'; ctx.lineWidth = 1.5;
      ctx.strokeRect(-width, -depth, width * 2, depth * 2);
      ctx.fillStyle = '#d6c39a';
      ctx.fillRect(-3 * scale / 2, depth - 1, 3 * scale, 3);
      ctx.restore();
    }
    if (state.zoneRadius != null) {
      const zoneCenter = state.zoneCenter || { x: 0, z: 0 };
      const [zx, zy] = point(zoneCenter.x, zoneCenter.z);
      const zr = Math.max(0, state.zoneRadius) * scale;
      ctx.fillStyle = '#7a4b8c66';
      ctx.beginPath(); ctx.rect(0, 0, size, size); ctx.arc(zx, zy, zr, 0, Math.PI * 2, true); ctx.fill('evenodd');
      ctx.setLineDash([5, 3]); ctx.strokeStyle = state.inDanger ? '#ffad9d' : '#cdb5ed'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(zx, zy, zr, 0, Math.PI * 2); ctx.stroke(); ctx.setLineDash([]);
    }
    if (state.player) {
      const [px, py] = point(state.player.x, state.player.z);
      ctx.fillStyle = '#ebd9a4'; ctx.shadowColor = '#ebd9a4'; ctx.shadowBlur = 12; ctx.beginPath(); ctx.arc(px, py, 4.5, 0, Math.PI * 2); ctx.fill(); ctx.shadowBlur = 0;
      ctx.strokeStyle = '#f7edc880'; ctx.lineWidth = 1.5; ctx.beginPath(); ctx.arc(px, py, 8.5, 0, Math.PI * 2); ctx.stroke();
    }
    ctx.restore();
    ctx.strokeStyle = '#c2ad7250'; ctx.lineWidth = 1; ctx.beginPath(); ctx.arc(center, center, center - 3, 0, Math.PI * 2); ctx.stroke();
  }

  function update(state) {
    latestState = state;
    if (state.phase && state.phase !== currentPhase) setPhase(state.phase);
    const maxHealth = state.maxHealth || 100;
    const health = Math.max(0, Math.min(maxHealth, state.health ?? maxHealth));
    const roundedHealth = Math.ceil(health);
    if (health !== lastHealth) {
      healthFill.style.width = `${(health / maxHealth) * 100}%`;
      healthValue.innerHTML = `${roundedHealth} <small>/ ${maxHealth}</small>`;
      healthBar.setAttribute('aria-valuenow', String(roundedHealth));
      healthBar.setAttribute('aria-valuemax', String(maxHealth));
      healthBar.classList.toggle('low-health', health / maxHealth < .3);
      if (lastHealth >= 0 && roundedHealth < Math.ceil(lastHealth)) {
        root.classList.remove('hit');
        // A class animation gives damage feedback without rebuilding the HUD.
        requestAnimationFrame(() => root.classList.add('hit'));
      }
      lastHealth = health;
    }
    const danger = Boolean(state.inDanger);
    root.classList.toggle('in-tall-grass', Boolean(state.hiddenInGrass));
    zoneTime.textContent = timeLabel(state.zoneCountdown || 0);
    zoneRadius.textContent = `${Math.round(state.zoneRadius ?? 44)} m`;
    zoneProgress.style.transform = `scaleX(${Math.max(0, Math.min(1, state.zoneProgress ?? 0))})`;
    zonePanel.classList.toggle('is-danger', danger);
    zoneLabel.textContent = danger ? 'IM GEFÄHRLICHEN NEBEL' : (state.zoneShrinking ? 'DIE ZONE SCHRUMPFT' : (state.zoneProgress >= 1 ? 'DIE LETZTE ZUFLUCHT' : 'DER NEBEL ZIEHT AUF'));
    playerStatus.textContent = state.shelter ? `In ${state.shelter} verborgen` :
      (state.hiddenInGrass ? 'Im hohen Gras verborgen' :
        (danger ? 'Der Nebel zehrt an dir' : (health < maxHealth ? 'Herzen geben dir neue Kraft' : 'Voller Lebenskraft')));
    root.classList.toggle('in-danger', danger);
    if (danger !== lastDanger) { dangerWarning.classList.toggle('visible', danger); lastDanger = danger; }
    crystalCount.textContent = String(state.crystals || 0);
    const dashCooldown = Math.max(0, state.rollCooldown ?? state.dashCooldown ?? 0);
    dashButton.classList.toggle('on-cooldown', dashCooldown > 0);
    dashButton.disabled = dashCooldown > 0 || currentPhase !== 'playing';
    dashButton.style.setProperty('--cooldown', Math.min(1, dashCooldown / (state.rollCooldownDuration || state.dashCooldownDuration || 2.5)));
    const weaponType = typeof state.equippedWeapon === 'string' ? state.equippedWeapon : state.equippedWeapon?.type;
    const weaponLabel = weaponType === 'bow' ? 'Bogen' : weaponType === 'sword' ? 'Schwert' : 'Leer';
    if (weaponType !== lastWeaponType) {
      weaponName.textContent = weaponLabel;
      weaponIcon.innerHTML = icon(weaponType === 'bow' ? 'bow' : weaponType === 'sword' ? 'sword' : 'shield');
      weaponStatus.setAttribute('aria-label', `Ausgerüstete Waffe: ${weaponLabel}`);
      attackButton.querySelector('.icon').outerHTML = icon(weaponType === 'bow' ? 'bow' : 'sword');
      attackButton.setAttribute('aria-label', weaponType === 'bow' ? 'Mit dem Bogen schießen' : weaponType === 'sword' ? 'Mit dem Schwert angreifen' : 'Angriff: keine Waffe ausgerüstet');
      lastWeaponType = weaponType;
    }
    const attackCooldown = Math.max(0, state.attackCooldown ?? 0);
    attackButton.disabled = !['bow', 'sword'].includes(weaponType) || attackCooldown > 0 || currentPhase !== 'playing';
    attackButton.classList.toggle('on-cooldown', attackCooldown > 0);
    const nearWeaponType = typeof state.nearWeapon === 'string' ? state.nearWeapon : state.nearWeapon?.type;
    const canPickUp = currentPhase === 'playing' && ['bow', 'sword'].includes(nearWeaponType);
    pickupPrompt.hidden = !canPickUp;
    interactButton.hidden = !canPickUp;
    interactButton.disabled = !canPickUp;
    if (nearWeaponType !== lastNearWeaponType) {
      const nearLabel = nearWeaponType === 'bow' ? 'Bogen' : nearWeaponType === 'sword' ? 'Schwert' : '';
      pickupItem.textContent = nearLabel;
      pickupPrompt.setAttribute('aria-label', `${nearLabel} mit E aufnehmen`);
      interactButton.setAttribute('aria-label', `${nearLabel} aufheben`);
      lastNearWeaponType = nearWeaponType;
    }
    const now = performance.now();
    if (now - lastMapTime > 90) { drawMap(state); lastMapTime = now; }
    if (state.quality && $('qualityMode')) $('qualityMode').value = state.quality;
  }

  function toast(message, tone = 'default') {
    clearTimeout(toastTimeout);
    toastElement.textContent = message;
    toastElement.dataset.tone = tone;
    toastElement.classList.add('visible');
    toastTimeout = setTimeout(() => toastElement.classList.remove('visible'), 2800);
  }

  return {
    update, setPhase, toast,
    joystick: $('joystick'), joystickKnob: $('joystickKnob'), dashButton, attackButton, interactButton,
    setLoading(message) { $('startBtn').disabled = Boolean(message); $('startBtn').querySelector('span').textContent = message || 'Insel betreten'; },
    showError(message) { $('errorMessage').textContent = message; $('errorScreen').hidden = false; },
  };
}
