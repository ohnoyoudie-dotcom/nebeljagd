import * as THREE from 'three';
import './style.css';
import { createWorld } from './world.js';
import { createCharacter } from './character.js';
import { createPickups } from './pickups.js';
import { createZone } from './zone.js';
import { createWeapons } from './weapons.js';
import { createUI } from './ui.js';
import { MAX_HEALTH, START_HEALTH, WALK_SPEED, ROLL_SPEED, ROLL_DURATION, ROLL_COOLDOWN,
  zoneAt, isInDanger, healthAfterDamage, healedHealth } from './rules.js';

const coarsePointer = window.matchMedia('(pointer: coarse)').matches;
const state = {
  phase: 'ready', health: START_HEALTH, maxHealth: MAX_HEALTH, elapsed: 0,
  crystals: 0, inDanger: false, moving: false, distance: 0,
  rollCooldown: 0, rollRemaining: 0, direction: Math.PI, quality: coarsePointer ? 'low' : 'high',
};
const keys = new Set();
const stick = new THREE.Vector2();
let ready = false;
let inputPointer = null;

const ui = createUI({
  onStart: () => { if (ready) { setPhase('playing'); ui.toast('Willkommen im Wald. Finde Herzen und bleib im sicheren Kreis.'); } },
  onPause: () => { if (state.phase === 'playing') setPhase('paused'); },
  onResume: () => { if (state.phase === 'paused') setPhase('playing'); },
  onRestart: () => { if (ready) reset(); },
  onDash: () => roll(),
  onAttack: () => attackWeapon(),
  onInteract: () => interactWeapon(),
  onQualityChange: (quality) => setQuality(quality),
});

let renderer;
try {
  renderer = new THREE.WebGLRenderer({ canvas: document.querySelector('#game'), antialias: true, powerPreference: 'high-performance' });
} catch (error) {
  ui.showError('Diese Welt benötigt WebGL 2. Bitte öffne sie in einem aktuellen Browser mit aktivierter Grafikbeschleunigung.');
  throw error;
}
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.18;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
const scene = new THREE.Scene();
scene.background = new THREE.Color('#a9c8bd');
scene.fog = new THREE.Fog('#a9c8bd', 65, 135);
const camera = new THREE.OrthographicCamera(-20, 20, 17, -17, 0.1, 180);
const cameraFocus = new THREE.Vector3(-8, 0, 8);
const cameraTarget = new THREE.Vector3();
const cameraOffset = new THREE.Vector3(0, 29, 18);

scene.add(new THREE.HemisphereLight('#e5f4dd', '#51675b', 2.0));
const sun = new THREE.DirectionalLight('#fff1d1', 3.2);
sun.position.set(-22, 42, 20);
sun.castShadow = true;
sun.shadow.camera.left = -49;
sun.shadow.camera.right = 49;
sun.shadow.camera.top = 49;
sun.shadow.camera.bottom = -49;
sun.shadow.camera.near = 1;
sun.shadow.camera.far = 110;
sun.shadow.bias = -0.00015;
sun.shadow.normalBias = 0.035;
sun.shadow.radius = 3;
scene.add(sun);

const world = createWorld(scene, { quality: state.quality });
const visualScale = world.visualScale;
const character = createCharacter(world.root);
character.group.scale.setScalar(1.2);
const player = character.group.position;
player.set(world.spawn.x, world.heightAt(world.spawn.x, world.spawn.z), world.spawn.z);
const pickups = createPickups(world.root);
const weapons = createWeapons(world.root, character.group, world);
const zone = createZone(world.root);
const inactivePlayer = new THREE.Vector3(1000, 0, 1000);
const moveDirection = new THREE.Vector3();
const lastPosition = new THREE.Vector3();
const rollDirection = new THREE.Vector3(0, 0, -1);
let currentZone = zoneAt(0);
let lastShelter = null;
let lastConcealment = false;

function clearInput() {
  keys.clear(); stick.set(0, 0); inputPointer = null;
  if (ui.joystickKnob) ui.joystickKnob.style.transform = 'translate(-50%, -50%)';
}

function setPhase(phase) {
  state.phase = phase;
  clearInput();
  state.moving = false;
  ui.setPhase(phase);
  character?.setDead(phase === 'dead');
  updateUI();
}

function reset() {
  Object.assign(state, { health: START_HEALTH, elapsed: 0, crystals: 0, inDanger: false,
    distance: 0, moving: false, rollCooldown: 0, rollRemaining: 0, direction: Math.PI,
    hiddenInGrass: false, shelter: null });
  player.set(world.spawn.x, world.heightAt(world.spawn.x, world.spawn.z), world.spawn.z);
  cameraFocus.copy(player).multiplyScalar(visualScale);
  pickups.reset(); weapons.reset(); character.setConcealed(false);
  lastConcealment = false; lastShelter = null; currentZone = zoneAt(0);
  setPhase('playing');
  ui.toast('Ein neuer Streifzug beginnt.');
}

function setQuality(quality) {
  state.quality = quality === 'low' ? 'low' : 'high';
  const high = state.quality === 'high';
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, high ? 1.75 : 1.15));
  const size = high ? 2048 : 1024;
  if (sun.shadow.mapSize.x !== size) {
    sun.shadow.mapSize.set(size, size);
    sun.shadow.map?.dispose(); sun.shadow.map = null;
  }
  resize();
}

function resize() {
  const width = window.innerWidth, height = window.innerHeight;
  const aspect = width / height;
  const viewHeight = (aspect < 0.8 ? 34 : 24) * visualScale;
  camera.left = -viewHeight * aspect / 2;
  camera.right = viewHeight * aspect / 2;
  camera.top = viewHeight / 2;
  camera.bottom = -viewHeight / 2;
  camera.updateProjectionMatrix();
  renderer.setSize(width, height);
}

function roll() {
  if (state.phase !== 'playing' || state.rollCooldown > 0) return;
  rollDirection.set(Math.sin(state.direction), 0, Math.cos(state.direction));
  state.rollRemaining = ROLL_DURATION;
  state.rollCooldown = ROLL_COOLDOWN;
  character.roll();
}

function interactWeapon() {
  if (state.phase !== 'playing') return;
  const result = weapons.interact(player);
  if (result) { ui.toast(result.message, 'success'); updateUI(); }
}

function attackWeapon() {
  if (state.phase !== 'playing') return;
  const result = weapons.attack(player, state.direction);
  if (!result && !weapons.equipped) ui.toast('Heb zuerst einen Bogen oder ein Schwert mit E auf.');
}

function simulate(dt) {
  if (state.phase !== 'playing') return;
  state.elapsed += dt;
  state.rollCooldown = Math.max(0, state.rollCooldown - dt);
  state.rollRemaining = Math.max(0, state.rollRemaining - dt);
  moveDirection.set(
    (keys.has('KeyD') || keys.has('ArrowRight') ? 1 : 0) - (keys.has('KeyA') || keys.has('ArrowLeft') ? 1 : 0) + stick.x,
    0,
    (keys.has('KeyS') || keys.has('ArrowDown') ? 1 : 0) - (keys.has('KeyW') || keys.has('ArrowUp') ? 1 : 0) + stick.y,
  );
  const inputLength = Math.min(1, moveDirection.length());
  if (moveDirection.lengthSq() > 0.001) moveDirection.normalize();
  if (state.rollRemaining > 0) moveDirection.copy(rollDirection);
  lastPosition.copy(player);
  const speed = state.rollRemaining > 0 ? ROLL_SPEED : WALK_SPEED * inputLength;
  player.addScaledVector(moveDirection, speed * dt);
  world.resolveMovement(player, 0.42);
  player.y = world.heightAt(player.x, player.z);
  const travelled = Math.hypot(player.x - lastPosition.x, player.z - lastPosition.z);
  state.moving = travelled > 0.0005;
  state.distance += travelled;
  if (state.moving) state.direction = Math.atan2(player.x - lastPosition.x, player.z - lastPosition.z);
  currentZone = zoneAt(state.elapsed);
  const wasInDanger = state.inDanger;
  state.inDanger = isInDanger(player, currentZone.radius);
  if (state.inDanger && !wasInDanger) ui.toast('Der Nebel zehrt an deiner Kraft. Zurück in den Kreis!', 'danger');
  if (!state.inDanger && wasInDanger) ui.toast('Du bist wieder in Sicherheit.', 'success');
  state.health = healthAfterDamage(state.health, dt, state.inDanger);
  if (state.health === 0) setPhase('dead');
}

function onCollect(item) {
  if (item.type === 'heart') {
    state.health = healedHealth(state.health, item.amount);
    ui.toast(`+${Math.round(item.amount)} Leben · Ein Geschenk des Waldes`, 'success');
  } else {
    state.crystals += item.amount;
    ui.toast('+1 Waldkristall', 'success');
  }
}

function updateUI() {
  ui.update({ ...state, zoneRadius: currentZone.radius, zoneCountdown: currentZone.countdown,
    zoneProgress: currentZone.progress, zoneShrinking: currentZone.shrinking,
    rollCooldownDuration: ROLL_COOLDOWN, equippedWeapon: weapons.equipped,
    nearWeapon: weapons.nearest(player), attackCooldown: weapons.attackCooldown,
    shelter: state.shelter, hiddenInGrass: Boolean(state.hiddenInGrass),
    houses: world.houses.map(house => ({ ...house, active: state.shelter === house.name,
      roofVisible: state.shelter !== house.name })),
    player: { x: player.x, z: player.z }, pickups: pickups.items,
  });
}

window.addEventListener('keydown', (event) => {
  if (event.code === 'Escape') {
    if (state.phase === 'playing') setPhase('paused');
    else if (state.phase === 'paused') setPhase('playing');
    return;
  }
  if (state.phase !== 'playing') return;
  if (['Space', 'KeyE', 'KeyF', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'KeyW', 'KeyA', 'KeyS', 'KeyD'].includes(event.code)) {
    event.preventDefault(); keys.add(event.code);
  }
  if (event.code === 'Space' && !event.repeat) roll();
  if (event.code === 'KeyE' && !event.repeat) interactWeapon();
  if (event.code === 'KeyF' && !event.repeat) attackWeapon();
});
window.addEventListener('keyup', (event) => keys.delete(event.code));
window.addEventListener('blur', () => {
  clearInput();
  if (state.phase === 'playing') setPhase('paused');
});
document.addEventListener('visibilitychange', () => {
  if (document.hidden && state.phase === 'playing') setPhase('paused');
});
window.addEventListener('resize', resize);

function moveStick(event) {
  const rect = ui.joystick.getBoundingClientRect();
  const limit = rect.width * 0.32;
  stick.set((event.clientX - rect.left - rect.width / 2) / limit,
    (event.clientY - rect.top - rect.height / 2) / limit);
  if (stick.length() > 1) stick.normalize();
  if (ui.joystickKnob) ui.joystickKnob.style.transform = `translate(-50%, -50%) translate(${stick.x * limit}px, ${stick.y * limit}px)`;
}
ui.joystick.addEventListener('pointerdown', (event) => {
  if (state.phase !== 'playing') return;
  event.preventDefault(); inputPointer = event.pointerId;
  ui.joystick.setPointerCapture(event.pointerId); moveStick(event);
});
ui.joystick.addEventListener('pointermove', (event) => { if (event.pointerId === inputPointer) moveStick(event); });
for (const eventName of ['pointerup', 'pointercancel', 'lostpointercapture']) {
  ui.joystick.addEventListener(eventName, (event) => {
    if (event.pointerId !== inputPointer) return;
    inputPointer = null; stick.set(0, 0);
    if (ui.joystickKnob) ui.joystickKnob.style.transform = 'translate(-50%, -50%)';
  });
}

document.querySelector('#game').addEventListener('webglcontextlost', (event) => {
  event.preventDefault();
  if (state.phase === 'playing') setPhase('paused');
  ui.showError('Die Grafikverbindung wurde unterbrochen. Lade die Seite neu, um die Insel erneut zu betreten.');
});

window.nebeljagdTestState = () => ({
  renderer: 'three-webgl2', phase: state.phase, health: state.health, maxHealth: state.maxHealth,
  elapsed: state.elapsed, moving: state.moving, distance: state.distance,
  position: { x: player.x, y: player.y, z: player.z }, direction: state.direction,
  rollCooldown: state.rollCooldown, dashCooldown: state.rollCooldown,
  rollRemaining: state.rollRemaining, crystals: state.crystals, quality: state.quality,
  equippedWeapon: weapons.equipped, attackCooldown: weapons.attackCooldown,
  nearWeapon: weapons.nearest(player)?.type ?? null,
  hiddenInGrass: Boolean(state.hiddenInGrass), hiddenFromOtherPlayers: Boolean(state.hiddenInGrass),
  concealment: world.concealmentAt(player.x, player.z), shelter: state.shelter ?? null,
  houses: world.houses.map(({ name, x, z, halfWidth, halfDepth }) => ({ name, x, z, halfWidth, halfDepth,
    roofVisible: !state.shelter || state.shelter !== name })),
  zone: { ...currentZone, inDanger: state.inDanger },
  pickups: pickups.items.map(({ id, type, x, z, collected }) => ({ id, type, x, z, collected })),
  rendering: { calls: renderer.info.render.calls, triangles: renderer.info.render.triangles,
    geometries: renderer.info.memory.geometries, textures: renderer.info.memory.textures },
});

setQuality(state.quality);
  cameraFocus.copy(player).multiplyScalar(visualScale);
ready = true;
ui.setPhase('ready');
ui.setLoading?.('');
let previousTime = performance.now(), accumulator = 0, time = 0, uiTimer = 0;
function frame(now) {
  const dt = Math.min(0.1, (now - previousTime) / 1000);
  previousTime = now; time += dt; accumulator += dt;
  while (accumulator >= 1 / 60) { simulate(1 / 60); accumulator -= 1 / 60; }
  world.update(dt, time, player);
  state.shelter = world.shelter;
  state.hiddenInGrass = world.concealmentAt(player.x, player.z) > 0.01;
  if (state.shelter !== lastShelter) {
    if (state.shelter) ui.toast(`Du betrittst ${state.shelter}. Das Dach öffnet sich über dir.`, 'success');
    else if (lastShelter) ui.toast('Du verlässt das Haus. Das Dach schließt sich wieder.');
    lastShelter = state.shelter;
  }
  if (state.hiddenInGrass !== lastConcealment) {
    ui.toast(state.hiddenInGrass ? 'Im hohen Gras verborgen. Andere Spieler können dich nicht sehen.' : 'Du verlässt das dichte Gras.');
    lastConcealment = state.hiddenInGrass;
  }
  character.setConcealed(state.hiddenInGrass);
  character.update(dt, time, { moving: state.moving, speed: state.rollRemaining > 0 ? ROLL_SPEED : WALK_SPEED,
    direction: state.direction, health: state.health });
  weapons.update(dt, time, player);
  pickups.update(dt, time, state.phase === 'playing' ? player : inactivePlayer,
    { health: state.health, maxHealth: MAX_HEALTH, onCollect });
  zone.update(time, currentZone.radius, state.inDanger);
  cameraTarget.set(player.x * visualScale, 0, (player.z - 1.5) * visualScale);
  cameraFocus.lerp(cameraTarget, 1 - Math.exp(-dt * 4));
  camera.position.copy(cameraFocus).add(cameraOffset); camera.lookAt(cameraFocus);
  renderer.render(scene, camera);
  uiTimer += dt;
  if (uiTimer > 0.08) { updateUI(); uiTimer = 0; }
  requestAnimationFrame(frame);
}
updateUI();
requestAnimationFrame(frame);
