import * as THREE from 'three';

/** Large wooden cottages. Positions and wall rectangles use the world's local X/Z coordinates. */
export function createHouses(root, houseSites) {
  const cube = new THREE.BoxGeometry(1, 1, 1);
  const makeMaterial = (color, extra = {}) => new THREE.MeshStandardMaterial({
    color, roughness: 0.91, flatShading: true, ...extra,
  });
  const material = {
    foundation: makeMaterial('#879184'),
    foundationEdge: makeMaterial('#5d6e65'),
    floor: makeMaterial('#a77b51'),
    floorLight: makeMaterial('#bd8f5f'),
    wall: makeMaterial('#b38b60'),
    wallLight: makeMaterial('#c19b70'),
    wallLines: makeMaterial('#896545'),
    timber: makeMaterial('#644735'),
    timberLight: makeMaterial('#8b6245'),
    roofBase: makeMaterial('#745d43'),
    roofA: makeMaterial('#91714e'),
    roofB: makeMaterial('#82664a'),
    roofC: makeMaterial('#725a42'),
    roofMoss: makeMaterial('#63765b'),
    glass: makeMaterial('#95b7ac', { metalness: 0.13, roughness: 0.33, emissive: '#426a5e', emissiveIntensity: 0.23 }),
    gold: makeMaterial('#efcf8a', { metalness: 0.28, roughness: 0.47, emissive: '#aa753c', emissiveIntensity: 0.23 }),
    linen: makeMaterial('#e0d5b3'),
    beddingA: makeMaterial('#557871'),
    beddingB: makeMaterial('#92705f'),
    rug: makeMaterial('#6a8275'),
    rugTrim: makeMaterial('#d4b879'),
    books: makeMaterial('#978060'),
    hearth: makeMaterial('#6d7470'),
  };
  const walls = [];
  const houses = [];
  const hw = 8;
  const hd = 7;
  const wallThickness = 0.36;
  const height = 3.25;

  for (const site of houseSites) {
    const group = new THREE.Group();
    group.name = `Holzhaus ${site.name}`;
    group.position.set(site.x, 0, site.z);
    root.add(group);
    const outer = new THREE.Group();
    outer.name = 'Außenwände'; group.add(outer);
    const frontFacade = new THREE.Group();
    frontFacade.name = 'Abnehmbarer vorderer Wandteil'; group.add(frontFacade);
    const interior = new THREE.Group();
    interior.name = 'Wohnraum und zwei Schlafzimmer'; group.add(interior);
    const roof = new THREE.Group();
    roof.name = 'Abnehmbares Dach'; group.add(roof);
    const porch = new THREE.Group();
    porch.name = 'Eingang und Veranda'; group.add(porch);

    // Batch equal materials into one draw call per group, including hundreds of roof tiles.
    const batches = new Map();
    function plank(parent, mat, x, y, z, w, h, d, rotationZ = 0) {
      let byMaterial = batches.get(parent);
      if (!byMaterial) { byMaterial = new Map(); batches.set(parent, byMaterial); }
      let list = byMaterial.get(mat);
      if (!list) { list = []; byMaterial.set(mat, list); }
      list.push({ x, y, z, w, h, d, rotationZ });
    }
    function wall(parent, x, z, width, depth, mat = material.wall, wallHeight = height) {
      plank(parent, mat, x, 0.37 + wallHeight / 2, z, width, wallHeight, depth);
      walls.push({
        minX: site.x + x - width / 2, maxX: site.x + x + width / 2,
        minZ: site.z + z - depth / 2, maxZ: site.z + z + depth / 2,
      });
    }
    function trim(parent, x, z, width, depth, y = 0.37 + height + 0.08) {
      plank(parent, material.timber, x, y, z, width, 0.17, depth);
    }

    // A raised, beveled stone sill and distinct boards across the floor.
    plank(group, material.foundation, 0, 0.18, 0, hw * 2 + 0.8, 0.36, hd * 2 + 0.8);
    plank(group, material.foundationEdge, 0, 0.06, 0, hw * 2 + 1.0, 0.14, hd * 2 + 1.0);
    plank(interior, material.floor, 0, 0.42, 0, hw * 2, 0.15, hd * 2);
    for (let i = 0; i < 17; i++) {
      plank(interior, i % 3 ? material.floorLight : material.floor, -hw + 0.48 + i * 0.94,
        0.515, 0, 0.075, 0.025, hd * 2 - 0.2);
    }

    // The front is open at its center, and both rear rooms have broad doorways.
    wall(outer, 0, -hd, hw * 2, wallThickness, material.wallLight);
    wall(outer, -hw, 0, wallThickness, hd * 2);
    wall(outer, hw, 0, wallThickness, hd * 2);
    const entryHalf = 1.45;
    const frontWidth = hw - entryHalf;
    for (const side of [-1, 1]) {
      const cx = side * (entryHalf + frontWidth / 2);
      wall(frontFacade, cx, hd, frontWidth, wallThickness);
    }
    // A timber frame reads clearly from the raised, almost top-down camera.
    for (const x of [-hw, hw]) for (const z of [-hd, hd]) {
      plank(z === hd ? frontFacade : outer, material.timber, x, 2.02, z, 0.28, height + 0.3, 0.32);
    }
    for (const x of [-entryHalf - 0.11, entryHalf + 0.11]) {
      plank(frontFacade, material.timber, x, 2.02, hd + 0.04, 0.21, height + 0.24, 0.24);
    }
    trim(outer, 0, -hd, hw * 2 + 0.6, 0.47);
    trim(outer, -hw, 0, 0.45, hd * 2 + 0.5);
    trim(outer, hw, 0, 0.45, hd * 2 + 0.5);
    for (const side of [-1, 1]) trim(frontFacade, side * (entryHalf + frontWidth / 2), hd, frontWidth + 0.2, 0.47);
    plank(frontFacade, material.timber, 0, height + 0.49, hd + 0.10, entryHalf * 2 + 0.45, 0.28, 0.32);
    for (let level = 1; level <= 7; level++) {
      const y = 0.44 + level * 0.41;
      plank(outer, material.wallLines, 0, y, -hd - 0.20, hw * 2 - 0.35, 0.045, 0.08);
      for (const side of [-1, 1]) {
        plank(outer, material.wallLines, side * (hw + 0.20), y, 0, 0.08, 0.045, hd * 2 - 0.4);
        plank(frontFacade, material.wallLines, side * (entryHalf + frontWidth / 2), y, hd + 0.20,
          frontWidth - 0.16, 0.045, 0.08);
      }
    }

    // Windows and dark shutters face the path, with matching side windows.
    for (const side of [-1, 1]) {
      const x = side * 5.22;
      plank(frontFacade, material.timber, x, 2.13, hd + 0.25, 2.1, 1.55, 0.15);
      plank(frontFacade, material.glass, x, 2.13, hd + 0.34, 1.64, 1.14, 0.10);
      for (const edge of [-1, 1]) {
        plank(frontFacade, material.timberLight, x + edge * 0.76, 2.13, hd + 0.42, 0.12, 1.14, 0.12);
      }
      plank(frontFacade, material.timberLight, x, 2.12, hd + 0.43, 0.11, 1.12, 0.12);
      for (const z of [-3.35, 3.35]) {
        plank(outer, material.timber, side * (hw + 0.25), 2.13, z, 0.13, 1.55, 2.0);
        plank(outer, material.glass, side * (hw + 0.34), 2.13, z, 0.10, 1.12, 1.55);
        plank(outer, material.timberLight, side * (hw + 0.43), 2.13, z, 0.11, 0.10, 1.6);
      }
    }
    // Stone steps and two modest lanterns mark the threshold.
    plank(porch, material.foundation, 0, 0.14, hd + 0.8, 4.05, 0.27, 1.65);
    plank(porch, material.floorLight, 0, 0.30, hd + 0.5, 3.20, 0.12, 1.20);
    for (const x of [-1.9, 1.9]) {
      plank(porch, material.timber, x, 2.19, hd + 0.29, 0.13, 0.95, 0.16);
      plank(porch, material.gold, x, 1.72, hd + 0.37, 0.28, 0.42, 0.28);
      plank(porch, material.timber, x, 1.52, hd + 0.38, 0.4, 0.10, 0.4);
    }

    // One generous family room occupies the whole southern half. A rear wall
    // has two separate, wide bedroom doors; a center partition divides the bedrooms.
    const dividingZ = -0.68;
    const sectionEdges = [[-hw, -5.25], [-2.75, 2.75], [5.25, hw]];
    for (const [left, right] of sectionEdges) {
      wall(interior, (left + right) / 2, dividingZ, right - left, 0.25, material.wallLight, 2.6);
      plank(interior, material.timber, (left + right) / 2, 3.06, dividingZ, right - left, 0.12, 0.32);
    }
    wall(interior, 0, (dividingZ - hd) / 2, 0.27, hd + dividingZ, material.wallLight, 2.55);
    // The bedroom doors have a 2.5-unit clear opening, well above player width.
    for (const x of [-5.25, -2.75, 2.75, 5.25]) {
      plank(interior, material.timber, x, 1.75, dividingZ, 0.18, 2.8, 0.30);
    }
    for (const centerX of [-4, 4]) {
      plank(interior, material.timber, centerX, 3.22, dividingZ, 2.5, 0.18, 0.32);
    }
    plank(interior, material.rugTrim, 0, 0.56, 3.22, 4.9, 0.038, 3.45);
    plank(interior, material.rug, 0, 0.582, 3.22, 4.65, 0.024, 3.21);
    // Central table, four seats and a bread-and-herbs setting.
    plank(interior, material.timberLight, 0, 1.40, 3.28, 2.45, 0.15, 1.46);
    for (const x of [-0.98, 0.98]) for (const z of [2.75, 3.81]) {
      plank(interior, material.timber, x, 0.97, z, 0.16, 0.98, 0.16);
    }
    plank(interior, material.gold, 0, 1.51, 3.25, 0.68, 0.045, 0.49);
    for (const x of [-2.22, 2.22]) {
      plank(interior, material.timberLight, x, 1.0, 3.28, 0.48, 0.14, 1.18);
      plank(interior, material.timber, x, 0.60, 3.28, 0.12, 0.77, 1.02);
    }
    // Hearth and bookshelves define opposite corners of the living room.
    plank(interior, material.hearth, -5.9, 0.89, 0.72, 2.1, 1.0, 1.34);
    plank(interior, material.timber, -5.9, 1.42, 0.72, 2.15, 0.13, 1.4);
    plank(interior, material.gold, -5.9, 1.57, 0.72, 0.38, 0.30, 0.28);
    plank(interior, material.timber, 6.82, 1.58, 1.54, 0.47, 2.15, 2.42);
    for (const y of [0.92, 1.44, 1.96, 2.47]) plank(interior, material.floorLight, 6.68, y, 1.54, 0.75, 0.11, 2.52);
    for (let i = 0; i < 10; i++) {
      plank(interior, i % 2 ? material.books : material.beddingB, 6.62, 1.05 + Math.floor(i / 3) * 0.5,
        0.66 + (i % 3) * 0.76, 0.35, 0.42, 0.15);
    }
    // Two full-sized bedrooms, each with a large bed, low rug, nightstand and shelves.
    for (const side of [-1, 1]) {
      const bedX = side * 4.25;
      const bedroomZ = -4.24;
      plank(interior, material.rugTrim, bedX, 0.55, bedroomZ, 4.45, 0.035, 3.55);
      plank(interior, side < 0 ? material.beddingA : material.beddingB, bedX, 0.573, bedroomZ, 4.17, 0.024, 3.28);
      plank(interior, material.timber, bedX, 0.79, -5.22, 2.18, 0.52, 2.75);
      plank(interior, material.linen, bedX, 1.10, -5.22, 2.02, 0.15, 2.54);
      plank(interior, side < 0 ? material.beddingA : material.beddingB, bedX, 1.18, -5.72, 1.98, 0.12, 1.15);
      plank(interior, material.linen, bedX, 1.27, -4.43, 1.21, 0.11, 0.46);
      plank(interior, material.timberLight, bedX + side * 2.18, 0.80, -4.72, 0.78, 0.62, 0.80);
      plank(interior, material.gold, bedX + side * 2.18, 1.19, -4.72, 0.22, 0.16, 0.22);
      for (const y of [1.29, 1.78, 2.27]) {
        plank(interior, material.timberLight, side * 7.30, y, -2.23, 0.55, 0.12, 2.05);
      }
    }

    // A pitched roof with individually offset wooden tiles and a mossy ridge.
    const slope = Math.atan(1.42 / hw);
    for (const side of [-1, 1]) {
      const panel = new THREE.Mesh(new THREE.BoxGeometry(8.22, 0.20, hd * 2 + 0.85), material.roofBase);
      panel.position.set(side * 4.04, 4.30, 0);
      panel.rotation.z = -side * slope;
      panel.castShadow = panel.receiveShadow = true;
      roof.add(panel);
      for (let row = 0; row < 8; row++) {
        const x = side * (0.53 + row * 0.99);
        const y = 5.01 - Math.abs(x) * (1.42 / hw) + 0.135;
        for (let column = 0; column < 8; column++) {
          const z = -6.62 + column * 1.9 + (row % 2 ? 0.28 : 0);
          const swatch = (row + column) % 8 === 0 ? material.roofMoss :
            [material.roofA, material.roofB, material.roofC][(row * 3 + column) % 3];
          plank(roof, swatch, x, y, z, 1.07, 0.085, 1.92, -side * slope);
        }
      }
    }
    plank(roof, material.timber, 0, 5.11, 0, 0.27, 0.33, hd * 2 + 1.04);
    // A pair of wooden end gables closes the silhouette above the wall line.
    const shape = new THREE.Shape();
    shape.moveTo(-hw, 0); shape.lineTo(0, 1.42); shape.lineTo(hw, 0); shape.closePath();
    const gableGeometry = new THREE.ShapeGeometry(shape);
    for (const z of [-hd - 0.17, hd + 0.17]) {
      const gable = new THREE.Mesh(gableGeometry, material.timberLight);
      gable.position.set(0, 3.62, z);
      gable.material.side = THREE.DoubleSide;
      roof.add(gable);
    }
    // A modest stone chimney is kept with the roof so the entire top disappears.
    plank(roof, material.hearth, -4.7, 5.12, -3.9, 1.1, 1.86, 1.12);
    plank(roof, material.foundationEdge, -4.7, 6.12, -3.9, 1.36, 0.17, 1.37);

    for (const [parent, byMaterial] of batches) {
      for (const [mat, pieces] of byMaterial) {
        const instances = new THREE.InstancedMesh(cube, mat, pieces.length);
        instances.castShadow = instances.receiveShadow = true;
        const dummy = new THREE.Object3D();
        pieces.forEach((piece, index) => {
          dummy.position.set(piece.x, piece.y, piece.z);
          dummy.rotation.set(0, 0, piece.rotationZ);
          dummy.scale.set(piece.w, piece.h, piece.d);
          dummy.updateMatrix();
          instances.setMatrixAt(index, dummy.matrix);
        });
        instances.instanceMatrix.needsUpdate = true;
        parent.add(instances);
      }
    }
    interior.visible = false;
    houses.push({ name: site.name, x: site.x, z: site.z, halfWidth: hw, halfDepth: hd,
      floorHeight: 0.50, group, roof, frontFacade, interior });
  }
  return { houses, walls };
}
