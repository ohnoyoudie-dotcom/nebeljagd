import * as THREE from 'three';

/** A small, animated forest traveller. All geometry is made once, at startup. */
export function createCharacter(scene) {
  const group = new THREE.Group();
  group.name = 'Waldläufer';
  const body = new THREE.Group();
  group.add(body);

  const material = (color, extra = {}) => new THREE.MeshStandardMaterial({
    color, roughness: 0.84, flatShading: true, ...extra,
  });
  const colors = {
    cloth: material('#267b72'),
    hood: material('#398b7c'),
    darkCloth: material('#1c5357'),
    leather: material('#744b31'),
    leatherLight: material('#a87949'),
    pants: material('#374445'),
    skin: material('#e5b58b'),
    hair: material('#d1a254'),
    gold: material('#e6c574', { metalness: 0.3, roughness: 0.48 }),
    steel: material('#c4d8d0', { metalness: 0.6, roughness: 0.3 }),
    eyes: material('#243b3a'),
    gem: material('#7be1c6', { emissive: '#248c78', emissiveIntensity: 0.65 }),
  };
  function mesh(geometry, mat, parent, x = 0, y = 0, z = 0) {
    const item = new THREE.Mesh(geometry, mat);
    item.position.set(x, y, z);
    item.castShadow = true;
    item.receiveShadow = true;
    parent.add(item);
    return item;
  }
  const box = (x, y, z) => new THREE.BoxGeometry(x, y, z);
  const sphere = (r, width = 10, height = 8) => new THREE.SphereGeometry(r, width, height);

  // Tunic and a flared coat hem make the silhouette readable from above.
  mesh(new THREE.CylinderGeometry(0.29, 0.35, 0.60, 8), colors.cloth, body, 0, 1.12);
  mesh(new THREE.CylinderGeometry(0.32, 0.40, 0.25, 8), colors.darkCloth, body, 0, 0.78);
  mesh(new THREE.CylinderGeometry(0.345, 0.35, 0.105, 8), colors.leather, body, 0, 0.93);
  mesh(box(0.16, 0.13, 0.055), colors.gold, body, 0, 0.93, 0.33);
  mesh(box(0.08, 0.065, 0.06), colors.leather, body, 0, 0.93, 0.36);
  const strap = mesh(box(0.085, 0.61, 0.055), colors.leatherLight, body, -0.025, 1.19, 0.29);
  strap.rotation.z = -0.47;
  mesh(new THREE.OctahedronGeometry(0.075), colors.gem, body, 0.16, 1.31, 0.30);

  const legs = [];
  const arms = [];
  for (const side of [-1, 1]) {
    const leg = new THREE.Group();
    leg.position.set(side * 0.18, 0.76, 0);
    body.add(leg);
    mesh(new THREE.CylinderGeometry(0.115, 0.10, 0.42, 6), colors.pants, leg, 0, -0.19);
    mesh(box(0.24, 0.22, 0.36), colors.leather, leg, 0, -0.57, 0.05);
    mesh(box(0.25, 0.065, 0.38), colors.darkCloth, leg, 0, -0.695, 0.05);
    mesh(box(0.255, 0.055, 0.25), colors.leatherLight, leg, 0, -0.47, 0.005);
    legs.push(leg);

    const arm = new THREE.Group();
    arm.position.set(side * 0.36, 1.32, 0);
    arm.rotation.z = side * 0.12;
    body.add(arm);
    mesh(sphere(0.17), colors.hood, arm, side * 0.035, -0.035);
    mesh(new THREE.CylinderGeometry(0.13, 0.10, 0.32, 7), colors.cloth, arm, side * 0.045, -0.18);
    mesh(new THREE.CylinderGeometry(0.105, 0.095, 0.17, 7), colors.leather, arm, side * 0.045, -0.405);
    mesh(sphere(0.10), colors.skin, arm, side * 0.045, -0.51, 0.015);
    arms.push(arm);
  }

  const head = new THREE.Group();
  head.position.y = 1.66;
  body.add(head);
  const hood = mesh(sphere(0.405, 12, 9), colors.hood, head, 0, 0.10, -0.045);
  hood.scale.set(1, 1.04, 1);
  // An open hood, rather than a helmet: warm skin and hair remain visible.
  const face = mesh(sphere(0.29), colors.skin, head, 0, 0.055, 0.225);
  face.scale.set(0.87, 0.95, 0.65);
  const hoodRim = mesh(new THREE.TorusGeometry(0.286, 0.065, 6, 12, Math.PI * 1.7), colors.darkCloth, head, 0, 0.065, 0.225);
  hoodRim.rotation.z = Math.PI * 0.65;
  const fringe = mesh(sphere(0.26), colors.hair, head, 0, 0.25, 0.22);
  fringe.scale.set(0.94, 0.36, 0.65);
  mesh(box(0.10, 0.14, 0.10), colors.hair, head, -0.195, 0.12, 0.255).rotation.z = -0.15;
  mesh(box(0.075, 0.13, 0.08), colors.hair, head, 0.19, 0.13, 0.26).rotation.z = 0.15;
  for (const side of [-1, 1]) {
    mesh(sphere(0.025, 6, 6), colors.eyes, head, side * 0.093, 0.055, 0.401);
  }
  const nose = mesh(sphere(0.042, 6, 5), colors.skin, head, 0, -0.01, 0.421);
  nose.scale.set(0.8, 1, 1);
  mesh(new THREE.ConeGeometry(0.15, 0.29, 5), colors.hood, head, 0, 0.27, -0.28).rotation.x = -0.6;

  // Travel pack and rolled blanket sit above the short, animated cape.
  const pack = mesh(box(0.40, 0.43, 0.23), colors.leather, body, 0, 1.20, -0.33);
  pack.rotation.x = -0.10;
  mesh(box(0.28, 0.16, 0.07), colors.leatherLight, body, 0, 1.14, -0.475);
  mesh(box(0.065, 0.12, 0.035), colors.gold, body, 0, 1.19, -0.52);
  const blanket = mesh(new THREE.CylinderGeometry(0.12, 0.12, 0.48, 8), colors.darkCloth, body, 0, 1.49, -0.34);
  blanket.rotation.z = Math.PI / 2;

  const capeGeometry = new THREE.PlaneGeometry(0.69, 0.73, 4, 5);
  const capePositions = capeGeometry.attributes.position;
  const capeBase = new Float32Array(capePositions.array);
  const capeMat = material('#215e65', { side: THREE.DoubleSide });
  const cape = mesh(capeGeometry, capeMat, body, 0, 1.00, -0.30);
  cape.rotation.x = -0.19;

  // A short silver trail blade, carried low rather than blocking the face.
  const weapon = new THREE.Group();
  weapon.position.set(0.05, -0.51, 0.02);
  weapon.rotation.x = -0.24;
  arms[1].add(weapon);
  mesh(new THREE.CylinderGeometry(0.035, 0.035, 0.16, 6), colors.leather, weapon, 0, -0.035);
  mesh(box(0.23, 0.045, 0.065), colors.gold, weapon, 0, -0.12);
  const blade = mesh(new THREE.ConeGeometry(0.075, 0.48, 4), colors.steel, weapon, 0, -0.36);
  blade.rotation.z = Math.PI;
  blade.scale.z = 0.38;
  mesh(new THREE.OctahedronGeometry(0.055), colors.gem, weapon, 0, 0.075);
  // Weapons are found in the world; the traveller starts empty-handed.
  weapon.visible = false;

  const slashMaterial = new THREE.MeshBasicMaterial({
    color: '#fce7a5', transparent: true, opacity: 0,
    depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide,
  });
  const slash = new THREE.Mesh(new THREE.TorusGeometry(0.9, 0.035, 5, 24, Math.PI * 1.25), slashMaterial);
  slash.position.set(0, 0.7, 0.25);
  slash.rotation.x = Math.PI / 2;
  slash.visible = false;
  group.add(slash);
  scene.add(group);

  let walkPhase = 0;
  let walkBlend = 0;
  let attackTime = 0;
  let rollTime = 0;
  const rollDuration = 0.52;
  let dead = false;
  const originalShadow = new Map();
  let concealed = false;
  const bodyMeshes = [];
  group.traverse(part => {
    if (!part.isMesh) return;
    originalShadow.set(part, part.castShadow);
    if (part !== slash) bodyMeshes.push(part);
  });
  const normalCapeColor = capeMat.color.clone();
  const dangerCapeColor = new THREE.Color('#9d6255');

  function update(dt, time, { moving = false, speed = 5, direction = 0, health = 100 } = {}) {
    const blend = 1 - Math.exp(-dt * 12);
    walkBlend = THREE.MathUtils.lerp(walkBlend, moving && !dead ? 1 : 0, blend);
    walkPhase += dt * Math.max(5, Math.min(12, speed * 1.8));
    const gait = Math.sin(walkPhase);
    const sway = Math.sin(time * 2.2);
    const yaw = Math.atan2(Math.sin(direction - group.rotation.y), Math.cos(direction - group.rotation.y));
    group.rotation.y += yaw * Math.min(1, dt * 14);
    body.position.y = Math.abs(Math.sin(walkPhase)) * 0.07 * walkBlend + Math.sin(time * 2.8) * 0.012;
    body.rotation.z = gait * 0.035 * walkBlend;
    body.rotation.x = dead ? THREE.MathUtils.lerp(body.rotation.x, -1.1, blend) : -0.055 * walkBlend;
    if (rollTime > 0 && !dead) {
      rollTime = Math.max(0, rollTime - dt);
      const progress = 1 - rollTime / rollDuration;
      body.rotation.x = Math.PI * 2 * progress;
      body.rotation.z = 0;
      body.position.y = 1.05 * (1 - Math.cos(progress * Math.PI * 2));
    }
    legs[0].rotation.x = gait * 0.66 * walkBlend;
    legs[1].rotation.x = -gait * 0.66 * walkBlend;
    arms[0].rotation.x = -gait * 0.48 * walkBlend + 0.08;
    arms[1].rotation.x = gait * 0.48 * walkBlend + 0.08;
    head.rotation.z = -gait * 0.025 * walkBlend;
    head.rotation.x = sway * 0.025 * (1 - walkBlend);
    for (let i = 0; i < capePositions.count; i++) {
      const x = capeBase[i * 3];
      const y = capeBase[i * 3 + 1];
      const fall = 0.5 - y / 0.73;
      capePositions.setXYZ(i, x + Math.sin(time * 4 + fall * 3) * 0.025 * fall,
        y, -fall * (0.08 + walkBlend * 0.20) + Math.sin(time * 5 + x * 5) * 0.05 * fall);
    }
    capePositions.needsUpdate = true;
    capeGeometry.computeVertexNormals();
    if (health < 30 && !dead) {
      capeMat.color.copy(normalCapeColor).lerp(dangerCapeColor, (Math.sin(time * 4) + 1) * 0.12);
    } else capeMat.color.copy(normalCapeColor);
    if (attackTime > 0) {
      attackTime = Math.max(0, attackTime - dt);
      const progress = 1 - attackTime / 0.36;
      arms[1].rotation.x -= Math.sin(progress * Math.PI) * 1.8;
      slash.visible = !concealed;
      slash.rotation.z = -1.4 + progress * 2.8;
      slashMaterial.opacity = Math.sin(progress * Math.PI) * 0.85;
      slash.scale.setScalar(0.72 + progress * 0.45);
    } else slash.visible = false;
  }

  return {
    group,
    update,
    attack() { if (!dead) attackTime = 0.36; },
    roll() { if (!dead) rollTime = rollDuration; },
    setDead(value) { dead = Boolean(value); if (!dead) body.rotation.x = 0; else rollTime = 0; },
    setConcealed(value) {
      const shouldConceal = Boolean(value);
      if (concealed === shouldConceal) return;
      concealed = shouldConceal;
      for (const part of bodyMeshes) {
        let ancestor = part;
        while (ancestor && ancestor !== head) ancestor = ancestor.parent;
        const isHead = ancestor === head;
        part.visible = isHead || !concealed;
        part.castShadow = concealed ? false : originalShadow.get(part);
      }
      weapon.visible = false;
      slash.visible = !concealed && attackTime > 0;
      group.userData.hiddenFromOtherPlayers = concealed;
    },
  };
}
