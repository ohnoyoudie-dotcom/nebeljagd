import * as THREE from 'three';

/** Ground loot and lightweight, purely visual weapon attacks. */
export function createWeapons(scene, characterGroup, world) {
  const material = (color, extra = {}) => new THREE.MeshStandardMaterial({
    color, roughness: 0.72, flatShading: true, ...extra,
  });
  const wood = material('#925631');
  const darkWood = material('#57351f');
  const leather = material('#47392c');
  const brass = material('#e6bd68', { metalness: 0.5, roughness: 0.35 });
  const steel = material('#d7e8ee', { metalness: 0.66, roughness: 0.26 });
  const steelDark = material('#83aab3', { metalness: 0.58, roughness: 0.34 });
  const string = material('#eee4be', { emissive: '#7e8b68', emissiveIntensity: 0.2 });
  const gem = material('#8df3d6', { emissive: '#22b8a2', emissiveIntensity: 0.8 });

  const box = (x, y, z) => new THREE.BoxGeometry(x, y, z);
  function addMesh(parent, geometry, meshMaterial, x = 0, y = 0, z = 0) {
    const mesh = new THREE.Mesh(geometry, meshMaterial);
    mesh.position.set(x, y, z);
    mesh.castShadow = true;
    parent.add(mesh);
    return mesh;
  }

  function makeBow() {
    const group = new THREE.Group();
    group.name = 'Holzbogen';
    const curve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0.02, -0.69, 0),
      new THREE.Vector3(-0.17, -0.52, 0),
      new THREE.Vector3(-0.34, -0.19, 0),
      new THREE.Vector3(-0.39, 0, 0),
      new THREE.Vector3(-0.34, 0.19, 0),
      new THREE.Vector3(-0.17, 0.52, 0),
      new THREE.Vector3(0.02, 0.69, 0),
    ]);
    addMesh(group, new THREE.TubeGeometry(curve, 24, 0.052, 6, false), wood);
    addMesh(group, new THREE.CylinderGeometry(0.009, 0.009, 1.38, 4), string, 0.02, 0, 0);
    addMesh(group, box(0.15, 0.26, 0.13), leather, -0.39, 0, 0);
    for (const side of [-1, 1]) {
      addMesh(group, new THREE.SphereGeometry(0.064, 6, 5), brass, 0.02, side * 0.69, 0);
      addMesh(group, box(0.075, 0.11, 0.09), darkWood, -0.18, side * 0.53, 0);
    }
    addMesh(group, new THREE.OctahedronGeometry(0.055), gem, -0.39, 0.01, 0.09);
    return group;
  }

  function makeSword() {
    const group = new THREE.Group();
    group.name = 'Eisenschwert';
    addMesh(group, new THREE.CylinderGeometry(0.047, 0.055, 0.37, 6), leather, 0, -0.26, 0);
    addMesh(group, new THREE.OctahedronGeometry(0.105), brass, 0, -0.48, 0);
    const guard = addMesh(group, box(0.43, 0.075, 0.12), brass, 0, -0.045, 0);
    guard.rotation.z = -0.04;
    addMesh(group, box(0.12, 0.11, 0.12), steelDark, 0, 0.04, 0);
    const blade = addMesh(group, new THREE.CylinderGeometry(0, 0.118, 0.78, 4), steel, 0, 0.48, 0);
    blade.rotation.y = Math.PI / 4;
    addMesh(group, box(0.029, 0.57, 0.012), steelDark, 0, 0.35, 0.092);
    addMesh(group, new THREE.OctahedronGeometry(0.065), gem, 0, -0.055, 0.09);
    return group;
  }

  const definitions = [
    { type: 'bow', x: -4, z: 11, color: '#6bf0ce', phase: 0 },
    { type: 'sword', x: -11, z: 6, color: '#ffd480', phase: 1.7 },
  ];
  const ringGeometry = new THREE.RingGeometry(0.53, 0.6, 28);
  const haloGeometry = new THREE.CircleGeometry(0.76, 28);
  const items = definitions.map(definition => {
    const groundY = world?.heightAt?.(definition.x, definition.z) ?? 0;
    const group = new THREE.Group();
    group.name = definition.type === 'bow' ? 'Bogen auf dem Boden' : 'Schwert auf dem Boden';
    group.position.set(definition.x, groundY, definition.z);
    const floating = new THREE.Group();
    floating.position.y = 0.75;
    const visual = definition.type === 'bow' ? makeBow() : makeSword();
    visual.rotation.x = -Math.PI / 2;
    visual.rotation.z = -0.24;
    floating.add(visual);
    group.add(floating);
    const ringMaterial = new THREE.MeshBasicMaterial({
      color: definition.color, transparent: true, opacity: 0.75,
      side: THREE.DoubleSide, depthWrite: false,
    });
    const ring = new THREE.Mesh(ringGeometry, ringMaterial);
    ring.rotation.x = -Math.PI / 2;
    ring.position.y = 0.043;
    group.add(ring);
    const halo = new THREE.Mesh(haloGeometry, new THREE.MeshBasicMaterial({
      color: definition.color, transparent: true, opacity: 0.15,
      side: THREE.DoubleSide, depthWrite: false,
    }));
    halo.rotation.x = -Math.PI / 2;
    halo.position.y = 0.035;
    group.add(halo);
    scene.add(group);
    return { ...definition, group, floating, visual, ring, ringMaterial, collected: false };
  });

  const heldBow = makeBow();
  heldBow.position.set(-0.47, 1.18, 0.36);
  heldBow.rotation.set(-0.12, -0.25, -0.12);
  heldBow.visible = false;
  characterGroup.add(heldBow);
  const heldSword = makeSword();
  heldSword.position.set(0.47, 1.13, 0.26);
  heldSword.rotation.set(0.13, 0, -0.32);
  heldSword.visible = false;
  characterGroup.add(heldSword);

  const arrowWood = material('#b77740');
  const arrowFeather = material('#ffedbf', { side: THREE.DoubleSide });
  const arrowGlow = new THREE.MeshBasicMaterial({
    color: '#ffd78c', transparent: true, opacity: 0.26,
    depthWrite: false, blending: THREE.AdditiveBlending,
  });
  const arrowShaftGeometry = new THREE.CylinderGeometry(0.026, 0.03, 0.69, 5);
  const arrowHeadGeometry = new THREE.ConeGeometry(0.085, 0.23, 5);
  const arrowFeatherGeometry = box(0.15, 0.024, 0.2);
  const arrowTrailGeometry = new THREE.ConeGeometry(0.085, 0.8, 5);
  const arrows = Array.from({ length: 8 }, () => {
    const group = new THREE.Group();
    group.name = 'Fliegender Pfeil';
    group.visible = false;
    const shaft = addMesh(group, arrowShaftGeometry, arrowWood);
    shaft.rotation.x = Math.PI / 2;
    const head = addMesh(group, arrowHeadGeometry, steel, 0, 0, 0.43);
    head.rotation.x = Math.PI / 2;
    const feather = addMesh(group, arrowFeatherGeometry, arrowFeather, 0, 0, -0.34);
    feather.rotation.z = Math.PI / 4;
    const trail = addMesh(group, arrowTrailGeometry, arrowGlow, 0, 0, -0.83);
    trail.rotation.x = Math.PI / 2;
    trail.castShadow = false;
    scene.add(group);
    return { group, life: 0, direction: 0, vx: 0, vz: 0 };
  });

  const slashMaterial = new THREE.MeshBasicMaterial({
    color: '#fff2ba', transparent: true, opacity: 0,
    side: THREE.DoubleSide, depthWrite: false, blending: THREE.AdditiveBlending,
  });
  const slash = new THREE.Mesh(new THREE.TorusGeometry(0.85, 0.058, 5, 28, Math.PI * 1.18), slashMaterial);
  slash.name = 'Schwertschwung';
  slash.position.set(0, 1.05, 0.57);
  slash.rotation.x = Math.PI / 2;
  slash.visible = false;
  characterGroup.add(slash);

  let equippedType = null;
  let cooldown = 0;
  let slashTime = 0;
  const pickupRadiusSquared = 1.85 * 1.85;

  function nearest(position) {
    if (!position) return null;
    let result = null;
    let bestDistanceSquared = pickupRadiusSquared;
    for (const item of items) {
      if (item.collected) continue;
      const dx = position.x - item.x;
      const dz = position.z - item.z;
      const distanceSquared = dx * dx + dz * dz;
      if (distanceSquared <= bestDistanceSquared) {
        bestDistanceSquared = distanceSquared;
        result = item;
      }
    }
    return result;
  }

  function interact(position) {
    const item = nearest(position);
    if (!item) return null;
    item.collected = true;
    item.group.visible = false;
    equippedType = item.type;
    cooldown = 0;
    heldBow.visible = equippedType === 'bow';
    heldSword.visible = equippedType === 'sword';
    return {
      type: item.type,
      message: item.type === 'bow' ? 'Holzbogen aufgenommen – mit F schießen.' : 'Eisenschwert aufgenommen – mit F zuschlagen.',
    };
  }

  function attack(position, direction) {
    if (!equippedType || cooldown > 0 || !position) return null;
    const angle = Number.isFinite(direction) ? direction : characterGroup.rotation.y;
    if (equippedType === 'bow') {
      // Cooldown and lifetime keep the fixed pool comfortably below capacity.
      const arrow = arrows.find(entry => entry.life <= 0) ?? arrows[0];
      arrow.life = 1.35;
      arrow.direction = angle;
      arrow.vx = Math.sin(angle) * 18;
      arrow.vz = Math.cos(angle) * 18;
      arrow.group.position.set(position.x + Math.sin(angle) * 0.8, position.y + 1.22,
        position.z + Math.cos(angle) * 0.8);
      arrow.group.rotation.y = angle;
      arrow.group.visible = true;
      cooldown = 0.42;
      return { type: 'bow', message: 'Pfeil abgeschossen' };
    }
    slashTime = 0.34;
    slash.visible = true;
    cooldown = 0.56;
    return { type: 'sword', message: 'Schwertschlag' };
  }

  function update(dt, time, position) {
    const delta = Math.max(0, Number.isFinite(dt) ? dt : 0);
    cooldown = Math.max(0, cooldown - delta);
    for (const item of items) {
      if (item.collected) continue;
      const wave = Math.sin(time * 2.2 + item.phase);
      item.floating.position.y = 0.72 + wave * 0.11;
      item.floating.rotation.y = Math.sin(time * 0.6 + item.phase) * 0.32;
      item.ring.scale.setScalar(1 + wave * 0.065);
      item.ringMaterial.opacity = 0.6 + (wave + 1) * 0.11;
    }
    const concealed = Boolean(characterGroup.userData.hiddenFromOtherPlayers);
    heldBow.visible = equippedType === 'bow' && !concealed;
    heldSword.visible = equippedType === 'sword' && !concealed;
    for (const arrow of arrows) {
      if (arrow.life <= 0) continue;
      arrow.life -= delta;
      if (arrow.life <= 0 || (world?.bounds && Math.hypot(arrow.group.position.x, arrow.group.position.z) > world.bounds)) {
        arrow.life = 0;
        arrow.group.visible = false;
        continue;
      }
      arrow.group.position.x += arrow.vx * delta;
      arrow.group.position.z += arrow.vz * delta;
      arrow.group.rotation.z = Math.sin((1.35 - arrow.life) * 11) * 0.035;
    }
    if (slashTime > 0) {
      slashTime = Math.max(0, slashTime - delta);
      const progress = 1 - slashTime / 0.34;
      slash.visible = !concealed && slashTime > 0;
      slash.rotation.z = -1.6 + progress * 3.2;
      slash.scale.setScalar(0.75 + progress * 0.55);
      slashMaterial.opacity = Math.sin(progress * Math.PI) * 0.88;
      heldSword.rotation.z = -0.32 - Math.sin(progress * Math.PI) * 0.9;
    } else {
      slash.visible = false;
      heldSword.rotation.z = -0.32;
    }
  }

  function reset() {
    equippedType = null;
    cooldown = 0;
    slashTime = 0;
    heldBow.visible = false;
    heldSword.visible = false;
    slash.visible = false;
    slashMaterial.opacity = 0;
    heldSword.rotation.z = -0.32;
    for (const item of items) {
      item.collected = false;
      item.group.visible = true;
    }
    for (const arrow of arrows) {
      arrow.life = 0;
      arrow.group.visible = false;
    }
  }

  return {
    items,
    get equipped() { return equippedType; },
    get attackCooldown() { return cooldown; },
    nearest,
    interact,
    attack,
    update,
    reset,
  };
}
