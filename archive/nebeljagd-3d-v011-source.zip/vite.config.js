import { defineConfig } from 'vite';

export default defineConfig({
  // Relative asset URLs also work when the game is hosted in a repository subdirectory.
  base: './',
});
