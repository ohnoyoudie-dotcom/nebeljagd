# Nebeljagd · Die Nebelinsel

Ein spielbarer 3D-Fantasy-Prototyp für den Browser: eine Insel mit drei großen begehbaren Holzhäusern, mehreren Zimmern, hohen Versteckgrasflächen, Fluss und Brücke, bewegtem Gras, wandernden Wolkenschatten, Sammelgegenständen, Bogen und Schwert sowie flächigem lila Giftnebel. Die Darstellung verwendet Three.js/WebGL 2; Vite stellt den Entwicklungsserver und den Produktionsbuild bereit.

## Entwicklung

Voraussetzung: Node.js ab **22.12.0** und npm. Die Bibliotheken werden lokal installiert; das Spiel benötigt keine externen Grafikdienste oder Zugangsdaten.

```sh
npm ci
npm run dev
```

Den vom Entwicklungsserver angegebenen Port im Browser öffnen. Für den Test auf einem iPad im selben Netzwerk die Netzwerkadresse des Entwicklungsrechners verwenden; `npm run dev` bindet bereits an alle Netzwerkschnittstellen.

```sh
npm test          # Regeln für Gesundheit, Gefahrenzone und Spielparameter
npm run build    # Produktionsdateien in dist/
npm run preview  # Den fertigen Build lokal prüfen
```

Ein Produktionsserver muss nur den Inhalt von `dist/` ausliefern. Relative Asset-Pfade unterstützen auch Hosting unter einem Unterverzeichnis.

Der Build erzeugt außerdem **`dist/nebeljagd.html`**: eine eigenständige Spielversion mit eingebettetem JavaScript und CSS. Diese Datei kann ohne Server direkt im Browser geöffnet und weitergegeben werden. Sie lädt keine externen Modelle, Skripte oder Schriftarten. Die Quelldatei `index.html` benötigt dagegen weiterhin Vite beziehungsweise den Build.

Die funktionalen Browserprüfungen verwenden Python Playwright und Chromium (in der Cloud-Umgebung bereits vorhanden):

```sh
# Während npm run preview auf Port 4173 läuft:
python3 tests/browser_smoke.py
```

Geprüft werden tatsächliche Bewegung, Herzen und Lebensbalken, Kristalle, Brückenüberquerung, Zonenschaden, Tod/Neustart, Pause, emulierte Touch-Bedienung sowie die eigenständige HTML-Version. Berichte und Screenshots liegen unter `test-results/`.

## Steuerung und Spielregeln

- **PC:** WASD oder Pfeiltasten bewegen die Figur; die Leertaste löst eine Rolle aus. Mit **E** hebst du einen Bogen oder ein Schwert auf. Mit **F** schießt du einen Pfeil beziehungsweise führst einen Schwertschlag aus. Mit Esc beziehungsweise der Pausetaste pausieren und fortsetzen.
- **Touch:** Den eingeblendeten Joystick und die Schaltflächen „Rolle“, „Aufheben“ und „Angriff“ verwenden. Das Pausenmenü bietet einen Modus mit geringerer Renderauflösung und Schattenauflösung.
- Die Figur startet mit **72 von 100 Lebenspunkten**. Herzen heilen beim Darüberlaufen um bis zu **25 Punkte** und bleiben bei voller Gesundheit liegen. Goldene Waldkristalle erhöhen den Sammelzähler.
- Die sichere Zone hat zunächst einen Radius von 32 Welteinheiten. Nach 40 Sekunden beginnt sie über drei Minuten auf einen Radius von 10 zu schrumpfen. Außerhalb verursacht der Nebel **11 Schadenspunkte pro Sekunde**. Bei null Lebenspunkten kann die Runde neu gestartet werden.
- Der Fluss kann über die Holzbrücke überquert werden. Bäume, größere Felsen und die Inselgrenze begrenzen die Bewegung. Gras reagiert auf Wind und auf die Spielfigur.
- Die drei 16 × 14 Welteinheiten großen Holzhäuser öffnen beim Betreten ihr Dach und zeigen einen weiträumigen Wohnraum mit zwei begehbaren Schlafzimmern, Möbeln und breiten Türöffnungen. Außerhalb bleiben Dächer und Schatten sichtbar.
- Sechs hohe Grasflächen bleiben beim Betreten stehen. Lokal bleibt nur der Kopf der Figur sichtbar; die Spielfigur markiert diesen Zustand als `hiddenFromOtherPlayers` für späteres Multiplayer.
- Bogen und Schwert liegen in der Startregion und können einzeln aufgehoben werden. Pfeile fliegen sichtbar über die Welt, das Schwert hat einen Nahkampfschwung. Treffer und Schaden an Gegnern kommen mit deren späterer Implementierung.

Der aktuelle Stand ist ein lokaler Erkundungs- und Überlebensprototyp. **Schreinfragen, Gegner, Multiplayer und Teams sind in der 3D-Version noch nicht aktiv.** Die Verbergung in hohem Gras ist für eine spätere Netzwerksynchronisation vorbereitet und wirkt zurzeit nur lokal. Die Darstellung und Bedienung müssen zusätzlich auf den tatsächlich verwendeten Schul-iPads geprüft werden; eine emulierte Touch-Ansicht ersetzt diesen Gerätetest nicht.

## Aufbau und Grafiken

`src/main.js` verbindet Eingabe und Spielablauf. `rules.js` enthält die Spielparameter und Regeln; `world.js`, `houses.js`, `character.js`, `pickups.js`, `weapons.js` und `zone.js` erzeugen die 3D-Szene. `ui.js` und `style.css` enthalten Oberfläche, Lebensbalken und Minikarte.

Die derzeitigen Modelle, Materialien und Animationen werden direkt mit Three.js erzeugt. Es werden keine externen Modellpakete nachgeladen. Später können Blender-Modelle als **glTF 2.0 / GLB** importiert werden; `.blend`-Dateien bleiben dabei die bearbeitbaren Quellen. Für Figuren sind benannte Stand- und Laufanimationen sowie einheitliche Skalierung und Materialkonventionen vorgesehen.

Die bisherigen Dateien `v06.html`, `v07.html`, `v09.html`, `v10.html` und `sprite-preview.html` bleiben als historische Referenzen im Repository erhalten. Insbesondere v07 enthält frühere 2D-Spielregeln; der neue Einstieg ist `index.html`.

