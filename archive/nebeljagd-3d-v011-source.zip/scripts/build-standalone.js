import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve('dist');
let html = await readFile(resolve(root, 'index.html'), 'utf8');
const script = html.match(/<script\b[^>]*\bsrc="([^"]+)"[^>]*><\/script>/);
const stylesheet = html.match(/<link\b[^>]*\brel="stylesheet"[^>]*\bhref="([^"]+)"[^>]*>/);
if (!script || !stylesheet) throw new Error('Expected one bundled script and stylesheet in dist/index.html');
const javascript = await readFile(resolve(root, script[1]), 'utf8');
const css = await readFile(resolve(root, stylesheet[1]), 'utf8');
html = html.replace(script[0], () => `<script type="module">${javascript.replace(/<\/script/gi, '<\\/script')}</script>`);
html = html.replace(stylesheet[0], () => `<style>${css}</style>`);
await writeFile(resolve(root, 'nebeljagd.html'), html);
console.log('Standalone browser game: dist/nebeljagd.html (no server or external files needed)');
